from console import console
console({})
