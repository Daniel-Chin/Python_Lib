from . import *
import interactive
from console import console
print(interactive.__all__)
console(globals())
